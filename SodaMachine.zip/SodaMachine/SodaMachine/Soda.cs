﻿namespace ConsoleApplication1
{
    public class Soda
    {
        public string Name { get; set; }
        public int Nr { get; set; }

    }
}
